<?php
require("../config.php");
?>

<html>
    <head>
        <title>Лабораторна №1</title>
        <link rel='stylesheet' href='Dudii_style.css' type='text/css'/>
    </head>
    <body>
        <div class="perel">
            <div class="header">
                <h2>Лабораторна №1</h2>
            </div>
            <div class="osn">
                <ul>
                    <?php
                        echo "<li><a href=\"Dudii_1.15.php\">Використання for, if, elseif, else, echo, блоків коду, операцій порівняння, доступ до змінних форми(5, 14-18, 21)</a></li>";
                        echo "<li><a href=\"Dudii_1.19.php\">Використання switch, if, else, echo, блоків коду, пробілів та коментарів, доступ до змінних форми(2-5, 15-17, 19)</a></li>";
                        echo "<li><a href=\"Dudii_1.20.php\">Використання while, if, else, echo, блоків коду, конкатенації рядків, перетворення типів, констант(6, 9, 11, 15-17, 20)</a></li>";
                        echo "<li><a href=\"Dudii_1.21.php\">Використання do...while, else, echo, блоків коду, змінні змінних, конкатенації рядків(6, 10, 15-17, 21)</a></li>";
                        echo "<li><a href=\"Dudii_example1_1_5_1.php\">Dudii_example1_1_5_1.php</a></li>";
                        echo "<li><a href=\"Dudii_example1_1_5_2.php\">Dudii_example1_1_5_2.php</a></li>";
                    ?>
                </ul>
            </div>
        </div>
        <div class="d1">
            <a href="../index.php">Назад</a>
        </div>
    </body>

</html>