<?php
require("../config.php");
?>

<html>

    <head>
        <title>Приклад форми Post</title>
        <link rel='stylesheet' href='Dudii_style.css' type='text/css'/>
    </head>

    <body>
        <div class="verh" id="div6">
            <form action="Dudii_example1_1_5_2.php" method="get" required>
                <input class="input_n" id="i1" type="text" name="formvariable"><br>
                <input class="button" id="b6" type="submit" value="Додати">
            </form>
        </div>
        <div class="d1">
            <a href="Dudii_lab1.php">Назад</a>
        </div>
    </body>

</html>